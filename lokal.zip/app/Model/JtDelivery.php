<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JtDelivery extends Model
{
    protected $table    = 'jt_delivery';
    public $timestamps  = false;
    public $primaryKey  = 'id';
}
