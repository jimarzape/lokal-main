<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JtWeight extends Model
{
    protected $table    = 'jt_weight';
    public $timestamps  = false;
    public $primaryKey  = 'id';
}
