var home = new home();
function home() 
{
	init();

	function init()
	{
		carousel();
	}

	function carousel()
	{

	}
}