<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="banner-container">
            <img src="/banners/banner1.png" class="img-100">
        </div>
    </div>
    <div class="col-md-12 ">
        <div class="item-container">
            <div class="item-header ">BRANDS </div>
            <div class="item-body">
                <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel"  data-interval="1000">
                    <div class="MultiCarousel-inner">
                        <?php $__currentLoopData = $_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="pad15">
                                <img src="<?php echo e($brands->brand_image); ?>" class="img-item-thumb" alt="<?php echo e($brands->brand_name); ?>">
                                <div class="carousel-label"><?php echo e($brands->brand_name); ?></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button class="btn btn-gold leftLst btn-noborder"><i class="fas fa-angle-left"></i></button>
                    <button class="btn btn-gold rightLst btn-noborder"><i class="fas fa-angle-right"></i></button>
                </div>
            </div>
        </div>
        <div class="item-container">
            <div class="item-header ">POPULAR PRODUCTS</div>
            <div class="item-body ">
                <div class="item-grid row">
                    <?php $__currentLoopData = $_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-2 col-sm-4 no-padding">
                        <div class="item-thumb">
                            <div class="text-center">
                                <img class="img-item-thumb" src="<?php echo e($popular->product_image); ?>" alt="<?php echo e($popular->product_name); ?>">
                                <div class="carousel-label"><?php echo e($popular->product_name); ?></div>
                            </div>
                            <div class="price-container">
                                <span class="color-red">₱&nbsp;<?php echo e(number_format($popular->product_price, 2)); ?></span>
                                <span class="pull-right"><?php echo e(number_format($popular->total_sold)); ?>&nbsp;Sold</span>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="/custom/js/carousel.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lokal\resources\views/home.blade.php ENDPATH**/ ?>