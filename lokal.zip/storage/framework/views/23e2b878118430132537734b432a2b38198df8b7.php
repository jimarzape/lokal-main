<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="banner-container">
            <img src="/banners/banner1.png" class="img-100">
        </div>
    </div>
    <div class="col-md-12 ">
        <div class="item-container">
            <div class="item-header ">BRANDS </div>
            <div class="item-body">
                <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel"  data-interval="1000">
                    <div class="MultiCarousel-inner">
                        <?php $__currentLoopData = $_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="pad15">
                                <img src="<?php echo e($brands->brand_image); ?>" class="img-item-thumb" alt="<?php echo e($brands->brand_name); ?>">
                                <div class="carousel-label"><?php echo e($brands->brand_name); ?></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button class="btn btn-gold leftLst btn-noborder"><i class="fas fa-angle-left"></i></button>
                    <button class="btn btn-gold rightLst btn-noborder"><i class="fas fa-angle-right"></i></button>
                </div>
            </div>
        </div>
        <div class="item-container">
            <div class="item-header ">ON SALE PRODUCTS </div>
            <div class="item-body">
                <div class="MultiCarousel" data-items="1,3,5,6" data-slide="1" id="MultiCarousel"  data-interval="1000">
                    <div class="MultiCarousel-inner">
                        <?php $__currentLoopData = $_sale; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <a class="link-plain" href="<?php echo e(route('product_url', $sale->friendly_url)); ?>">
                                <div class="item-thumb">
                                    
                                    <div class="text-center">
                                        <img class="img-item-thumb" src="<?php echo e($sale->product_image); ?>" alt="<?php echo e($sale->product_name); ?>">
                                        <div class="carousel-label"><?php echo e($sale->product_name); ?></div>
                                    </div>
                                    <div class="discount-container mb-n12 text-left">
                                        <span class="discount-content"><i><?php echo e(discount_str($sale->sale_price)); ?></i></span>&nbsp;
                                    </div>
                                    <div class="price-container text-left">
                                        <span class="color-red">₱&nbsp;<?php echo e(number_format($sale->product_price, 2)); ?></span>
                                        <span class="pull-right"><?php echo e(knumber($sale->total_sold).' Sold'); ?></span>
                                    </div>
                                    <div class="rating-container">
                                        <span class="item-rating" data-rating="<?php echo e($sale->rate_value); ?>"></span>
                                        <?php if($sale->rate_count > 0): ?><span class="f-12">(<?php echo e(knumber($sale->rate_count)); ?>)</span><?php endif; ?>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <button class="btn btn-gold leftLst btn-noborder"><i class="fas fa-angle-left"></i></button>
                    <button class="btn btn-gold rightLst btn-noborder"><i class="fas fa-angle-right"></i></button>
                </div>
            </div>
        </div>
        <div class="item-container">
            <div class="item-header ">POPULAR PRODUCTS</div>
            <div class="item-body ">
                <div class="item-grid row">
                    <?php $__currentLoopData = $_popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $popular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="col-md-2 col-sm-4 no-padding link-plain" href="<?php echo e(route('product_url', $popular->friendly_url)); ?>">
                        <div class="item-thumb">
                            <?php if($popular->sale_price != null): ?>
                                <div class="discount-span">
                                    <span><?php echo e(discount($popular->sale_price, $popular->product_price)); ?>%</span><br>
                                    <span class="f-10">OFF</span>
                                </div>
                            <?php endif; ?>
                            <div class="text-center">
                                <img class="img-item-thumb" src="<?php echo e($popular->product_image); ?>" alt="<?php echo e($popular->product_name); ?>">
                                <div class="carousel-label"><?php echo e($popular->product_name); ?></div>
                            </div>
                            <div class="discount-container mb-n12">
                                <span class="discount-content"><i><?php echo e(discount_str($popular->sale_price)); ?></i></span>&nbsp;
                            </div>
                            <div class="price-container">
                                <span class="color-red">₱&nbsp;<?php echo e(number_format($popular->product_price, 2)); ?></span>
                                <span class="pull-right"><?php echo e(knumber($popular->total_sold)); ?>&nbsp;Sold</span>
                            </div>
                            <div class="rating-container">
                                <span class="item-rating" data-rating="<?php echo e($popular->rate_value); ?>"></span>
                                <?php if($popular->rate_count > 0): ?><span class="f-12">(<?php echo e(knumber($popular->rate_count)); ?>)</span><?php endif; ?>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <div class="item-container">
            <div class="item-header ">DAILY FEEDS</div>
            <div class="item-body ">
                <div class="item-grid row">
                    <?php $__currentLoopData = $_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="col-md-2 col-sm-4 no-padding link-plain" href="<?php echo e(route('product_url', $items->friendly_url)); ?>">
                        <div class="item-thumb">
                            <?php if($items->sale_price != null): ?>
                                <div class="discount-span">
                                    <span><?php echo e(discount($items->sale_price, $items->product_price)); ?>%</span><br>
                                    <span class="f-10">OFF</span>
                                </div>
                            <?php endif; ?>
                            <div class="text-center">
                                <img class="img-item-thumb" src="<?php echo e($items->product_image); ?>" alt="<?php echo e($items->product_name); ?>">
                                <div class="carousel-label"><?php echo e($items->product_name); ?></div>
                            </div>
                            <div class="discount-container mb-n12">
                                <span class="discount-content"><i><?php echo e(discount_str($items->sale_price)); ?></i></span>&nbsp;
                            </div>
                            <div class="price-container">
                                <span class="color-red">₱&nbsp;<?php echo e(number_format($items->product_price, 2)); ?></span>
                                <span class="pull-right"><?php echo e(knumber($items->total_sold)); ?>&nbsp;Sold</span>
                            </div>
                            <div class="rating-container">
                                <span class="item-rating" data-rating="<?php echo e($items->rate_value); ?>"></span>
                                <?php if($items->rate_count > 0): ?><span class="f-12">(<?php echo e(knumber($items->rate_count)); ?>)</span><?php endif; ?>
                            </div>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-2m">
            <div class="col-sm-4">
                <button class="btn btn-gold btn-block">SEE MORE</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript" src="/custom/js/carousel.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lokal\resources\views/home.blade.php ENDPATH**/ ?>