<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
            <h1 class="text-center text-theme mb-1m">Sign Up</h1>
           <div class="row signup-container mb-2m">
               <div class="col-md-6 bg-theme text-center text-white">
                   <img src="/media/img/logo-white.png" class="logo-signup mt-6m">
                   <div class="signup-hr"></div>
                   <span class="signup-span mb-1m">Sing Up With</span>
                   <div class="row justify-content-center mb-2m">
                       <div class="col-md-8">
                           <button class="btn btn-block fb-btn">SIGN IN WITH FACEBOOK</button>
                       </div>
                       <div class="col-md-8">
                           <button class="btn btn-block google-btn">SIGN IN WITH GOOGLE</button>
                       </div>
                   </div>
               </div>
               <div class="col-md-6 bg-white ">
                    <form method="POST" action="<?php echo e(route('signup')); ?>" class="row pd-2m">
                        <?php echo csrf_field(); ?>
                       <div class="col-md-12">
                           <div class="form-group">
                               <label for="name" class=" col-form-label text-md-right f-12"><?php echo e(__('Full Name')); ?></label>
                                <input id="name" type="text" class="form-control <?php $__errorArgs = ['userFullName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="userFullName" value="<?php echo e(old('userFullName')); ?>" required autocomplete="name" autofocus placeholder="Enter your full name here">

                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                            <div class="form-group">
                                <label for="email" class="col-form-label text-md-right f-12">Mobile Number</label>
                                <input id="mobile" type="text" class="form-control" name="userMobile" value="<?php echo e(old('userMobile')); ?>" required autocomplete="mobile" placeholder="Enter your mobile no. here">

                                <?php $__errorArgs = ['userMobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="form-group">
                                <label for="email" class="col-form-label text-md-right f-12"><?php echo e(__('E-Mail Address')); ?></label>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['userEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="userEmail" value="<?php echo e(old('userEmail')); ?>" required autocomplete="email" placeholder="Enter your email address here">

                                <?php $__errorArgs = ['userEmail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="form-group">
                                <label for="password" class="col-form-label text-md-right f-12"><?php echo e(__('Password')); ?></label>
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password" placeholder="Type your password here">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="form-group">
                                <label for="password-confirm" class="col-form-label text-md-right f-12"><?php echo e(__('Confirm Password')); ?></label>
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confirm your password here">
                           </div>
                           <div class="form-group text-center">
                               <p class="f-12">By clicking "Register" you agreed to <a href="#">Terms & Conditions</a></p>
                           </div>
                           <div class="form-group">
                               <button class="btn btn-block btn-theme">SIGN UP</button>
                           </div>
                           <div class="form-group text-center">
                               <p class="f-12">Already have an account? Login <a href="<?php echo e(route('login')); ?>">here</a></p>
                           </div>
                       </div>
                   </form>
               </div>
           </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\lokal\resources\views/auth/register.blade.php ENDPATH**/ ?>